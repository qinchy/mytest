package com.qinchy.dynamiceval.service;

public interface AliPayConfigService {
    String getAlipayConfig();
}
