package com.qinchy.dynamiceval;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DynamicevalApplicationTests {

    @Test
    void contextLoads() {
    }

}
